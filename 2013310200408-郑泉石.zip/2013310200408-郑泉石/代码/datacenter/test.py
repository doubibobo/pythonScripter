import time


def main():
    url=1
    A(url)
    print url
def A(url):
    url=2

if __name__ == '__main__':
    main()
